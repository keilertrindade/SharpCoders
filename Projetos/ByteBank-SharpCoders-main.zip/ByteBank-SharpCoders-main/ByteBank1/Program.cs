﻿using ByteBank1.Model;
using ByteBank1.View;

namespace ByteBank1 {

    public class Program {

        public static void Main(string[] args) {

            List<Conta> contas = new List<Conta>();
            Console.WriteLine("testing");
            
            MenuView.ShowMenu();

        }

    }

}