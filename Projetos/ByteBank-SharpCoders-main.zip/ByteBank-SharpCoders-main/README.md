# Projeto bytebank

Projeto bancário desenvolvido na etapa 1 do programa Sharp Coders.

## Regras de negócio a serem implementadas

**RN1:** Permitir que um usuário faça login e logout
**RN2:** Permitir que um usuário após logado realize operações bancárias de:

  1. Saque
  2. Depósito
  3. Transferência

## Erros

Nosso usuário irá cometer erros e solicitar operaçõs potencialmente inválidas, então busque checar erros e apresentar uma mensagem de erro coerente para o usuário.

## Envio do vídeo

Envie um vídeo de até **2 minutos**, sem a necessidade de edição, porém demonstrando o funcionamento das regras de negócio solicitadas.

Mais instruções sobre o envio para o youtube estarão em vídeo complementar.

## Entrega da etapa

Os últimos commits e a entrega do link para o vídeo devem ser feitos até sexta 06/01/22.

-----

made with 💙 by Ímã Learning Place.